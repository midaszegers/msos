README 
In this zipped map are included all the material used to research how water intake can influence the physical
activity of students during COVID-19. This zipfile includes the code needed for building the scale, the data 
retrieved from this, the data retrieved from the Mi Band and the code in python used to clean and analyze it.


SCALE
calibration.ino
This code is made in arduino and can be used after building the scale to calibrate it back to 0 when there is no 
weight on it. 

final code loadcell and SD card.ino
This code is also made for arduino and let's you measure the weight on the scale and log it onto the SD card
in the data shield whenever there is some weight on it.


DATAFRAMES
df_steps_1.csv
The dataframe including the steps participant 1 set per hour of every day. 

df_water_1.csv
The dataframe including the amount of water participant 1 drank at what time.

df_steps_2.csv
The dataframe including the steps participant 2 set per hour of every day. 

df_water_2.csv
The dataframe including the amount of water participant 2 drank at what time.

df_steps_3.csv
The dataframe including the steps participant 3 set per hour of every day. 

df_water_3.csv
The dataframe including the amount of water participant 3 drank at what time.

df_steps_4.csv
The dataframe including the steps participant 4 set per hour of every day. 

df_water_4.csv
The dataframe including the amount of water participant 4 drank at what time.

df_steps.csv
The dataframe including the amount of steps the test subjects set per hour of day. This dataframe also 
includes the DayofWeek, DayPeriod, PartofWeek, Participant, Week and StepsCumulative.

df_water.csv
The dataframe including the water consumption of every participant. It showed the amount of water the participant
weighed and the time and day on which it was measured. It also includes the columns DayofWeek, DayPeriod,
PartofWeek, Participant, Week and WeightCumulative.


PYTHON CODES
df_water_notebook.ipynb
The code made in python 3 used to compile all the water dataframes into one and clean it a bit further.

df_steps_notebook.ipynb
The code made in python 3 used to compile all the steps dataframes into one and clean it a bit further.

visualization final.ipynb
The python code used to make the visualizations of the combined dataframes and the reliability of the 
data gathered in the two weeks.


CIRCUIT
circuit.jpg 
A schematic visualization of the circuit used to measure the weight.



